package swp302.topic6.evcoownership;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvCoOwnershipApplication {

    public static void main(String[] args) {
        SpringApplication.run(EvCoOwnershipApplication.class, args);
    }

}
